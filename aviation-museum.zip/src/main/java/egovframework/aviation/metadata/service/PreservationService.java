package egovframework.aviation.metadata.service;

import java.util.Map;

import org.apache.ibatis.annotations.Param;

import egovframework.aviation.metadata.vo.param.PreservationParamVO;

public interface PreservationService {

	int setPreservation(PreservationParamVO param);
	int setPreservationImage(Map<Integer, Object> map);

}
