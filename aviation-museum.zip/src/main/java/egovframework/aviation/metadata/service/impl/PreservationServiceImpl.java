package egovframework.aviation.metadata.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.aviation.metadata.service.PreservationService;
import egovframework.aviation.metadata.vo.param.PreservationParamVO;

@Service
public class PreservationServiceImpl implements PreservationService {
	
	@Autowired
	private PreservationMapper dao;
	
	@Override
	public int setPreservation(PreservationParamVO param) {
		return dao.setPreservation(param);
	}

	@Override
	public int setPreservationImage(Map<Integer, Object> map) {
		return dao.setPreservationImage(map);
	}

}
