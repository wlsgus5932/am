package egovframework.aviation.metadata.vo.image;

public class ImageTagVO {

}
